const logoImg = document.getElementById('logo-img');
const webNav = document.getElementById('web-nav');

function handleScroll() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const opacity = scrollTop === 0 ? 1 : 1 - Math.min(1, scrollTop / 200);
    logoImg.style.opacity = opacity;
}

window.addEventListener('scroll', handleScroll);

window.addEventListener('scroll', function () {
    var header = document.querySelector('.header');
    var navLinks = document.querySelectorAll('.nav-item');
    if (window.scrollY > header.offsetHeight) {
        navLinks.forEach(function (link) {
            link.style.color = '#000';
            webNav.style.backgroundColor = '#F5F5F5'
        });
    } else {
        navLinks.forEach(function (link) {
            link.style.color = '#fff';
            webNav.style.backgroundColor = 'transparent'
        });
    }
});

const headerHTML = `
<nav>
<div class="web-nav lato-regular" id="web-nav">
    <a id="homeBtn" class="nav-item" href="home.html">home</a>
    <a id="aboutBtn" class="nav-item" href="about.html">about us</a>
    <a id="servicesBtn" class="nav-item" href="services.html">our services</a>
    <a id="galleryBtn" class="nav-item" href="gallery.html">gallery</a>
    <a id="contactBtn" class="nav-item" href="contact.html">contact us</a>
    <hr>
</div>
</nav>
<div class="page-title">
<img id="logo-img" src="images/title.png" alt="The company logo.">
</div>
`;

const footerHTML = `
<div class="footer lato-regular" id="footer">
<hr>
<div class="flex-container">
    <div class="logo-img">
        <img src="images/footertitle.png" alt="Footer logo image." width=300px; height=130px;>
    </div>
    <div>
        <div class="flex-container site-map">
            <div>
                <a class="site-nav-item" href="home.html">home</a><br>
                <a class="site-nav-item" href="about.html">about us</a>
                <a class="site-nav-item" href="reviews.html">reviews</a>
            </div>
            <div>
                <a class="site-nav-item" href="services.html">our services</a><br>
                <a class="site-nav-item" href="gallery.html">gallery</a>
                <a class="site-nav-item" href="contact.html">contact us</a>
            </div>
        </div>
    </div>
</div>
<div class="contact-info">
    <div class="flex-container">
        <div id="clark"></div>
        <div>
            webdevjules@gmail.com
        </div>
        <div>
            (123)456-7890
        </div>
        <div id="clark"></div>
    </div>
</div>
<div class="social-media">
            <div class="flex-container">
                <div>
                    <img class="social-media-link" id="github" src="images/github-mark.png" alt="Github profile button." onclick="window.location.href='https://github.com/juliafsabino'" style="cursor: pointer;">
                    <img class="social-media-link" id="linkedin" src="images/linkedin-logo.png"
                        alt="Linkedin profile button."
                        onclick="window.location.href='https://www.linkedin.com/in/julia-freire-sabino-81514a249/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_recent_activity_content_view%3BOpXZkiB2Q5mwk%2BbKYp4CCQ%3D%3D'" style="cursor: pointer;">
                    <img class="social-media-link" id="insta" src="images/insta-logo.png" alt="Instagram profile button" onclick="window.location.href='#'"  style="cursor: pointer;">
                </div>
            </div>
        </div>
</div>
`;

// const headerElement = document.getElementById("header");
// headerElement.innerHTML = headerHTML;

const footerElement = document.getElementById("footer");
footerElement.innerHTML = footerHTML;
