const logoImg = document.getElementById('logo-img');
const greenBG = document.getElementById('header');

function handleScroll() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const opacity = scrollTop === 0 ? 1 : 1 - Math.min(1, scrollTop / 200);
    logoImg.style.opacity = opacity;
}

window.addEventListener('scroll', handleScroll);

window.addEventListener('scroll', function () {
    var header = document.querySelector('.header');
    var navLinks = document.querySelectorAll('.nav-item');
    if (window.scrollY > header.offsetHeight) {
        navLinks.forEach(function (link) {
            link.style.color = '#000';
        });
    } else {
        navLinks.forEach(function (link) {
            link.style.color = '#fff';
        });
    }
});

const footerHTML = `
  <footer>
    <div class="footer lato-regular">
      <hr>
      <div class="flex-container">
        <div class="logo-img">
          <img src="images/footertitle.png" alt="Footer logo image." width="300px" height="130px">
        </div>
        <div>
          <div class="flex-container site-map">
            <div>
              <a class="nav-item" href="home.html">home</a><br>
              <a class="nav-item" href="about.html">about us</a><br>
              <a class="nav-item" href="reviews.html">reviews</a>
            </div>
            <div>
              <a class="nav-item" href="services.html">our services</a><br>
              <a class="nav-item" href="gallery.html">gallery</a><br>
              <a class="nav-item" href="contact.html">contact us</a>
            </div>
          </div>
        </div>
        <div class="contact-info">
          <div class="flex-container">
            <div id="clark"></div>
            <div>
              webdevjules@gmail.com
            </div>
            <div>
              |
            </div>
            <div>
              (123)456-7890
            </div>
            <div id="clark"></div>
          </div>
        </div>
      </div>
    </div>
  </footer>
`;

const targetElement = document.getElementById("your-footer-container-id");
