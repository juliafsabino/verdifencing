const logoImg = document.getElementById('logo-img');

function handleScroll() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const opacity = scrollTop === 0 ? 1 : 1 - Math.min(1, scrollTop / 200);
    logoImg.style.opacity = opacity;
}

window.addEventListener('scroll', handleScroll);